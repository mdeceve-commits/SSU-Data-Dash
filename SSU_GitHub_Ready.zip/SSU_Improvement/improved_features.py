"""Property features and strictly earlier-sale market summaries.

The interface follows the course's fit/transform pattern: learn category levels
and historical tables on the training fold, then reuse them for prediction.
"""

import numpy as np
import pandas as pd

from features import square_feet


CATEGORICAL_COLUMNS = [
    "house_type_name", "house_style", "municipality", "community",
]

TEXT_PATTERNS = {
    "text_updated": r"\b(?:renovat\w*|updated|redone|remodel\w*|turnkey)\b",
    "text_original": r"\b(?:original|dated|tired|older)\b",
    "text_needs_work": r"as[- ]is|fixer|great bones|potential|canvas|modernize",
    "text_premium": r"\b(?:luxury|premium|designer)\b|high[- ]end",
    "text_finished_basement": r"\bfinished basement\b",
    "text_unfinished_basement": r"\bunfinished basement\b",
    "text_separate_entrance": r"separate (?:side )?entrance",
    "text_views": r"unobstructed|skyline|ravine|lake view",
    "text_outdoor": r"\b(?:balcony|terrace|deck|backyard)\b",
    "text_amenities": r"\b(?:gym|pool|concierge)\b|party room",
}


class EarlierSalesFeatures:
    """Look up log-price means in exact trailing 90-day and 365-day windows.

    Both window endpoints are determined from each row's listing date. Sales
    on that date or later are excluded, including the training row's own sale.
    Prefix sums make the lookups efficient without using future transactions.
    """

    LEVELS = {
        "type": ["house_type_name"],
        "community": ["community"],
        "community_type": ["community", "house_type_name"],
    }

    def fit(self, sales):
        history = sales.copy()
        area = square_feet(history["house_area"])
        history["log_price"] = np.log(history["sold_price"])
        history["log_ppsf"] = np.log(
            history["sold_price"] / area.where(area > 0)
        )
        history = history.sort_values(["date_sold", "ml_num"])
        self.groups = {}
        for level, columns in self.LEVELS.items():
            self.groups[level] = {}
            group_key = columns[0] if len(columns) == 1 else columns
            for key, rows in history.groupby(group_key, sort=False):
                key = key if isinstance(key, tuple) else (key,)
                dates = rows["date_sold"].to_numpy(dtype="datetime64[ns]")
                values = rows[["log_price", "log_ppsf"]].to_numpy(float)
                finite = np.isfinite(values)
                totals = np.vstack([
                    np.zeros((1, 2)),
                    np.cumsum(np.where(finite, values, 0.0), axis=0),
                ])
                counts = np.vstack([
                    np.zeros((1, 2)), np.cumsum(finite, axis=0),
                ])
                self.groups[level][key] = (dates, totals, counts)
        return self

    def transform(self, homes):
        output = pd.DataFrame(index=homes.index)
        dates = homes["date_listed"].to_numpy(dtype="datetime64[ns]")
        for level, columns in self.LEVELS.items():
            means = {}
            group_key = columns[0] if len(columns) == 1 else columns
            positions_by_key = homes.groupby(group_key, sort=False).indices
            for days in [90, 365]:
                values = np.full((len(homes), 2), np.nan)
                sample_count = np.zeros(len(homes))
                for key, positions in positions_by_key.items():
                    key = key if isinstance(key, tuple) else (key,)
                    table = self.groups[level].get(key)
                    if table is None:
                        continue
                    sold_dates, totals, counts = table
                    query_dates = dates[positions]
                    right = np.searchsorted(sold_dates, query_dates, side="left")
                    left = np.searchsorted(
                        sold_dates, query_dates - np.timedelta64(days, "D"),
                        side="left",
                    )
                    number = counts[right] - counts[left]
                    total = totals[right] - totals[left]
                    values[positions] = np.divide(
                        total, number, out=np.full_like(total, np.nan),
                        where=number > 0,
                    )
                    sample_count[positions] = number[:, 0]
                prefix = f"past_{level}_{days}d"
                output[prefix + "_log_price"] = values[:, 0]
                output[prefix + "_log_ppsf"] = values[:, 1]
                output[prefix + "_log_count"] = np.log1p(sample_count)
                means[days] = values[:, 0]
            output[f"past_{level}_recent_change"] = means[90] - means[365]
        return output


class PropertyFeatures:
    """Build consistent model inputs using training-only category levels."""

    def __init__(self, track, use_history=False):
        self.track = track
        self.use_history = use_history

    def fit(self, train):
        self.categories = {
            column: sorted(train[column].dropna().astype(str).unique())
            for column in CATEGORICAL_COLUMNS
        }
        if self.use_history:
            self.history = EarlierSalesFeatures().fit(train)
        return self

    def transform(self, homes):
        X = pd.DataFrame(index=homes.index)
        area = square_feet(homes["house_area"])
        bounds = homes["house_area"].astype(str).str.split("-", expand=True)
        bounds = bounds.reindex(columns=[0, 1])
        low = pd.to_numeric(bounds[0], errors="coerce")
        high = pd.to_numeric(bounds[1], errors="coerce").fillna(low)
        X["square_feet"] = area
        X["area_range_width"] = high - low
        X["log_square_feet"] = np.log1p(area.where(area >= 0))
        for column in [
            "bedrooms", "washrooms", "parking_total", "garage",
            "lot_front", "lot_depth", "latitude", "longitude",
        ]:
            X[column] = pd.to_numeric(homes[column], errors="coerce")
        X["lot_area"] = X["lot_front"] * X["lot_depth"]
        X["lot_size_missing"] = X["lot_front"].isna().astype(float)
        X["bathrooms_per_1000_sqft"] = (
            1000 * X["washrooms"] / area.where(area > 0)
        )
        X["bedrooms_per_1000_sqft"] = (
            1000 * X["bedrooms"] / area.where(area > 0)
        )
        listed = homes["date_listed"]
        X["months_since_2021"] = (
            listed - pd.Timestamp("2021-01-01")
        ).dt.days / 30.44
        X["month_sin"] = np.sin(2 * np.pi * listed.dt.month / 12)
        X["month_cos"] = np.cos(2 * np.pi * listed.dt.month / 12)
        remarks = homes["remarks"].fillna("").str.lower()
        for name, pattern in TEXT_PATTERNS.items():
            X[name] = remarks.str.contains(pattern, regex=True).astype(float)
        X["log_description_length"] = np.log1p(remarks.str.len())
        if self.track == "list_aware":
            price = pd.to_numeric(homes["list_price"], errors="coerce")
            X["log_list_price"] = np.log(price.where(price > 0))
            X["log_list_price_per_sqft"] = np.log(
                price.where(price > 0) / area.where(area > 0)
            )
        if self.use_history:
            X = pd.concat([X, self.history.transform(homes)], axis=1)
        X = X.replace([np.inf, -np.inf], np.nan).astype(float)
        for column in CATEGORICAL_COLUMNS:
            X[column] = pd.Categorical(
                homes[column], categories=self.categories[column]
            )
        return X
