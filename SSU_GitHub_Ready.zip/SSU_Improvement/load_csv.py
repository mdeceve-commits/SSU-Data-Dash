"""Load the three SSU Data Dash CSV datasets in PyCharm.

Setup:
1. Place this script and the competition's data.py in the project root.
2. Create a datasets folder in the project root containing:
   listings.csv, test_off_market.csv, and test_list_aware.csv.
3. Run python -m pip install pandas in the project's Terminal.
4. Right-click this script in PyCharm and select Run 'load_csv'.

By default, datasets are read from the folder next to this script, regardless
of the current working directory. To use another location, set the DATA_DIR
environment variable in the run configuration.

This script uses the official competition loader and preserves the original
data and missing values. It does not train a model.
"""

import os
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(
    os.environ.get("DATA_DIR", str(PROJECT_DIR / "datasets"))
).expanduser().resolve()


def load_datasets():
    """Return the training, off-market test, and list-aware test DataFrames."""
    if not (PROJECT_DIR / "data.py").is_file():
        raise FileNotFoundError(
            "Place the competition's data.py in the same folder as load_csv.py."
        )

    required = (
        "listings.csv",
        "test_off_market.csv",
        "test_list_aware.csv",
    )
    missing = [name for name in required if not (DATA_DIR / name).is_file()]
    if missing:
        raise FileNotFoundError(
            f"Data directory: {DATA_DIR}\n"
            f"Missing files: {', '.join(missing)}\n"
            "Check the folder path and remove download suffixes such as (1). "
            "For example, rename listings(1).csv to listings.csv."
        )

    # Configure the official loader to read local files without downloading.
    # The loader also converts date columns to pandas datetime values.
    os.environ["DATA_DIR"] = str(DATA_DIR)
    from data import load

    train = load("listings")
    test_off_market = load("off_market")
    test_list_aware = load("list_aware")

    if "sold_price" not in train.columns:
        raise ValueError("The training dataset is missing the target column: sold_price.")

    return train, test_off_market, test_list_aware


if __name__ == "__main__":
    # Each variable holds one dataset as an in-memory pandas DataFrame.
    train, test_off_market, test_list_aware = load_datasets()

    print(f"Data directory: {DATA_DIR}")
    print(f"Training dataset: {train.shape[0]:,} rows, {train.shape[1]} columns")
    print(
        f"Off-market test dataset: {test_off_market.shape[0]:,} rows, "
        f"{test_off_market.shape[1]} columns"
    )
    print(
        f"List-aware test dataset: {test_list_aware.shape[0]:,} rows, "
        f"{test_list_aware.shape[1]} columns"
    )

    print("\nFirst 5 rows of the training dataset (selected columns):")
    columns = [
        "ml_num", "sold_price", "list_price", "date_listed",
        "date_sold", "house_type_name", "bedrooms",
    ]
    print(train[columns].head().to_string(index=False))

    print("\nData loaded successfully. Use train for training and the test datasets for prediction.")
    print("house_area is preserved as text because it may contain ranges. Missing values are retained.")
