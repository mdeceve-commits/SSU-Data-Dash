# Model improvement results

## Main finding

Using richer property and neighbourhood features with gradient-boosted tree regression substantially improved the historical validation results. The list-aware model also benefited from predicting the sold-to-list ratio while retaining list price as its price anchor.

Each track contains the same 10,069 historical validation homes from December 2025 through May 2026. These results do not score either hidden test file.

| Track | Official baseline MdAPE | Selected model MdAPE | Relative reduction in MdAPE | Baseline MAPE | Selected MAPE |
|---|---:|---:|---:|---:|---:|
| Off-market | 20.84% | 9.79% | 53.0% | 27.43% | 12.39% |
| List-aware | 7.26% | 4.22% | 41.9% | 8.09% | 5.30% |

Median signed error also fell from +8.07% to +0.83% for off-market and from +5.68% to +0.87% for list-aware. Positive signed error indicates a tendency to overpredict.

## Selection and confirmation

The candidate lists and hyperparameters were fixed before the experiment. December 2025 through March 2026 were used for selection: 5,554 homes per track. The selection rule was the lowest pooled MdAPE, with pooled MAPE breaking ties. The selected names were saved before evaluating the new models on April and May 2026: 4,515 homes per track.

| Track | Selected model | Development MdAPE | Confirmation MdAPE | Confirmation baseline MdAPE |
|---|---|---:|---:|---:|
| Off-market | rich_hgb | 9.90% | 9.63% | 20.63% |
| List-aware | rich_ratio_hgb | 4.15% | 4.30% | 7.24% |

Baseline errors for April and May were already inspected in the previous step. The confirmation period therefore checks the new selections on reserved months, but is not a completely untouched blind test. The full six-month score includes the development months and should be described as historical validation performance.

![Monthly comparison](figures/monthly_model_comparison.png)

## Fixed candidate comparison

The following figures use the four development months only. All candidates receive the same monthly training cutoffs and evaluation homes.

| Off-market candidate | MdAPE | MAPE |
|---|---:|---:|
| Official nearest-sales baseline | 21.125% | 27.737% |
| Starter FeatureModel | 14.837% | 19.253% |
| Random forest with richer features | 14.862% | 19.198% |
| Rich-feature histogram gradient boosting | 9.898% | 12.473% |
| Rich features plus strictly earlier-sale summaries | 9.904% | 12.411% |

The historical-feature candidate was nearly tied with the selected richer-feature model: the MdAPE difference was about 0.006 percentage points. This is too small to support a broad claim that one is inherently better. The fixed selection rule chose the simpler model, which was then confirmed without those historical features.

The forest used 100 trees, depth at most 18, at least 8 samples per leaf, and at most 50,000 bootstrap rows per tree. This was a bounded-compute comparison, not a search for the best possible random forest.

| List-aware candidate | MdAPE | MAPE |
|---|---:|---:|
| Official list-price baseline | 7.268% | 8.112% |
| Recent median ratio calibration by property type | 4.604% | 5.858% |
| Starter FeatureModel | 4.452% | 5.666% |
| Rich-feature sold-to-list ratio boosting | 4.146% | 5.235% |

Even the simple calibration improved the development baseline. The selected model learns how the ratio varies with property attributes, location, description flags, and the price anchor.

## What was improved

1. **Continuous-target regression.** The classification teaching examples were adapted to regressors. The familiar fit/predict interface was retained.
2. **Richer observed property information.** The models now use community, municipality, house style, garage, lot area, missing-lot indicators, area-range width, and room counts relative to floor area. The starter already parsed floor-area ranges to their midpoint; that existing transformation was retained.
3. **Categorical and missing-value handling.** Categories are learned from each training fold. The forest uses one-hot encoding and training-fitted median imputation. Histogram gradient boosting uses native categorical and missing-value handling.
4. **Listing-description signals.** Fixed keywords describe updates, original finishes, work needed, basements, views, and amenities. These flags use the supplied listing descriptions and do not extract prices from them.
5. **Different target design by track.** Off-market retains log sale price as the training target. The list-aware boosting candidate predicts log(sold price / list price), then multiplies the predicted ratio by the known list price. The estimators use their squared-error loss on the transformed targets; MdAPE is used for model selection.
6. **Controlled complexity.** The richer boosting candidates use the same fixed learning rate, iteration count, leaf-size restriction, and L2 regularization. No hyperparameter grid search was run.
7. **Causal historical features were tested.** Optional 90-day and 365-day price summaries use only sales strictly before each row's listing date, including during training. They were retained as an experimental candidate rather than added to the final selection automatically.

The comparison between the starter and the richer model changes both the feature set and some estimator settings. It does not isolate the causal contribution of each added feature. The richer and historical-feature candidates share their settings, making their comparison more direct.

## Feature diagnostics

Permutation importance was calculated on March 2026 development homes, with three permutations per feature. The selected off-market model relied most strongly on community, floor area, property type, and washrooms. Lot area, parking, and descriptions indicating work needed also contributed to this diagnostic.

For list-aware, the known list price was the dominant anchor. Community, listed price per square foot, lot information, property type, and other attributes helped describe deviations from that anchor. The log-list-price importance includes its role in converting a predicted ratio back into a price.

Permutation importance measures model reliance under shuffled inputs; it is not a causal effect. Correlated features can share or mask importance, and individual feature shuffles can create unusual combinations.

![Feature reliance](figures/permutation_feature_importance.png)

## Remaining weaknesses

The selected off-market model's full-period MdAPE was 10.40% for Detached homes and 9.66% for Condo Apt homes. Co-Op Apt had 12.00% MdAPE, but only 48 validation examples, so its estimate is much less stable. In list-aware, Semi-Detached homes remained more difficult at 5.70% MdAPE, compared with 3.43% for Condo Apt homes.

These diagnostics suggest future work on error differences by property type and on the usefulness of more structured condition information in descriptions. They do not justify further tuning on the reserved confirmation months while continuing to call those months independent.

## Checks and reproducibility

- Nine focused unittest checks passed, including future-price perturbation, same-day exclusion, trailing-window cutoffs, row alignment, unknown categories, and forbidden off-market inputs.
- The original five starter modules were unchanged during the comparison experiment. Production integration subsequently updated `run.py` to use the frozen improved selections; `data.py`, `features.py`, `models.py`, and `check_submission.py` remain unchanged.
- Both selected tracks have one positive finite prediction for every historical validation home.
- Validation IDs, sale prices, and month labels match the original CSV.
- MdAPE and MAPE were independently recomputed and agree with the saved comparison.
- The selection event precedes confirmation evaluation in the execution log.
- Input and experiment source hashes are recorded.
- No hidden-test prices, external property records, or hidden-test scores were used.

See `COURSE_CONNECTIONS.md` for the specific supplied lesson pages and current official API references. The implementation uses scikit-learn's HistGradientBoostingRegressor; XGBRegressor was not tested in this experiment.

## Production integration

The official `run.py validate`, `report`, `predict`, and `check` entry points are now connected to the frozen selected models through `pipeline_models.py`. Final models are refitted on the 150,000 supplied sales through May 2026. Both hidden test files are predicted without changing selected models or tuning parameters. See `SUBMISSION_STATUS.md` and `reports/final_submission_audit.json` for production checks. Historical validation scores remain distinct from unavailable hidden-test scores.
