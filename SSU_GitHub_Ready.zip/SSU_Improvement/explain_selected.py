"""Measure permutation importance on the March development validation homes.

This is a diagnostic of model reliance, not a causal effect or a new model
selection step. Correlated features can share or mask importance.
"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "4")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance

import data
from improved_models import make_candidate


ROOT = Path(__file__).resolve().parent
os.environ.setdefault("DATA_DIR", str(ROOT / "datasets"))


def main():
    selected = json.loads((ROOT / "selected_models.json").read_text())["selected"]
    listings = data.load("listings")
    train = listings[listings["date_sold"] < pd.Timestamp("2026-03-01")]
    homes = listings[listings["date_sold"].dt.to_period("M") == pd.Period("2026-03")]
    for track, name in selected.items():
        wrapper = make_candidate(name, track).fit(train)
        if not hasattr(wrapper, "model"):
            print(f"{track}: {name} has no feature-based estimator; skipped.")
            continue
        inputs = data.hide_answers(homes, track)
        if hasattr(wrapper, "features"):
            X = wrapper.features.transform(inputs)
        else:
            X = wrapper.make_features(inputs)

        def negative_mdape(estimator, X_rows, true_price):
            prediction = np.exp(estimator.predict(X_rows))
            if getattr(wrapper, "predict_ratio", False):
                prediction *= np.exp(X_rows["log_list_price"].to_numpy(float))
            return -float(np.median(100 * np.abs(prediction - true_price) / true_price))

        result = permutation_importance(
            wrapper.model, X, homes["sold_price"].to_numpy(float),
            scoring=negative_mdape, n_repeats=3, random_state=0, n_jobs=1,
        )
        table = pd.DataFrame({
            "feature": X.columns,
            "increase_in_mdape_percentage_points": result.importances_mean,
            "repeat_standard_deviation": result.importances_std,
        }).sort_values("increase_in_mdape_percentage_points", ascending=False)
        table.to_csv(ROOT / "reports" / f"permutation_importance_{track}.csv", index=False)
        print(f"\n{track}: {name}; March 2026 development validation", flush=True)
        print(table.head(12).to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
