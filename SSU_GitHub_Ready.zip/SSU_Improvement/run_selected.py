"""Rerun the frozen selected models under the official monthly cutoffs.

Place the three competition CSVs in datasets/, then run this file in PyCharm.
The saved selected_models.json is used without performing model selection again.
"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "4")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")

import json
from pathlib import Path

import pandas as pd

import data
from compare_models import predict_month, summarize
from improved_models import make_candidate


ROOT = Path(__file__).resolve().parent
os.environ.setdefault("DATA_DIR", str(ROOT / "datasets"))


def main():
    selection = json.loads((ROOT / "selected_models.json").read_text())
    selected = selection["selected"]
    listings = data.load("listings")
    predictions = []
    months = selection["selection_months"] + selection["confirmation_months"]
    for month in months:
        period = pd.Period(month, freq="M")
        train = listings[listings["date_sold"] < period.start_time]
        homes = listings[listings["date_sold"].dt.to_period("M") == period]
        phase = "development" if month in selection["selection_months"] else "confirmation"
        for track, name in selected.items():
            model = make_candidate(name, track)
            rows, elapsed = predict_month(
                model, train, homes, month, track, name, phase
            )
            predictions.append(rows)
            print(f"{month} {track}: {len(rows):,} predictions in {elapsed:.1f}s", flush=True)
    predictions = pd.concat(predictions, ignore_index=True)
    predictions.to_csv(ROOT / "outputs/selected_validation_predictions.csv", index=False)
    scores = summarize(predictions, ["track", "model"])
    scores.to_csv(ROOT / "reports/selected_overall_metrics.csv", index=False)
    print(scores.to_string(index=False))


if __name__ == "__main__":
    main()
