"""Focused leakage and feature-contract checks using Python's unittest."""

import unittest

import numpy as np
import pandas as pd

import data
from improved_features import EarlierSalesFeatures, PropertyFeatures
from improved_models import PropertyBoostingModel, ListPriceCalibration


def example_sales():
    dates = pd.to_datetime(["2025-01-01", "2025-06-01", "2025-03-01"])
    return pd.DataFrame({
        "ml_num": ["old", "future", "same_day"],
        "date_sold": dates,
        "date_listed": pd.to_datetime(["2024-12-20", "2025-01-10", "2025-03-01"]),
        "sold_price": [100000.0, 10000000.0, 9000000.0],
        "list_price": [110000.0, 11000000.0, 10000000.0],
        "house_type_name": "Detached", "house_style": "2-Storey",
        "municipality": "Toronto", "community": "A",
        "bedrooms": 3, "washrooms": 2, "parking_total": 1,
        "garage": 1.0, "lot_front": np.nan, "lot_depth": np.nan,
        "latitude": 43.7, "longitude": -79.4, "house_area": "900-1100",
        "remarks": "Updated kitchen and unfinished basement.",
    })


class ImprovementChecks(unittest.TestCase):
    def test_history_excludes_future_and_same_day_sales(self):
        sales = example_sales()
        query = sales.iloc[[2]]
        features = EarlierSalesFeatures().fit(sales).transform(query)
        self.assertAlmostEqual(features.iloc[0]["past_type_90d_log_price"], np.log(100000))
        self.assertAlmostEqual(features.iloc[0]["past_type_90d_log_count"], np.log(2))

    def test_changing_future_prices_cannot_change_past_features(self):
        sales = example_sales()
        query = sales.iloc[[2]]
        before = EarlierSalesFeatures().fit(sales).transform(query)
        changed = sales.copy()
        changed.loc[1, "sold_price"] = 1e15
        after = EarlierSalesFeatures().fit(changed).transform(query)
        np.testing.assert_allclose(before, after, equal_nan=True)

    def test_trailing_window_excludes_old_sales(self):
        sales = example_sales().iloc[[0]].copy()
        query = example_sales().iloc[[2]].copy()
        query["date_listed"] = pd.Timestamp("2026-03-01")
        features = EarlierSalesFeatures().fit(sales).transform(query)
        self.assertTrue(features.filter(like="_log_price").isna().all().all())
        self.assertTrue((features.filter(like="_log_count") == 0).all().all())

    def test_off_market_features_exclude_forbidden_columns(self):
        sales = example_sales()
        builder = PropertyFeatures("off_market", use_history=True).fit(sales)
        X = builder.transform(data.hide_answers(sales, "off_market"))
        for column in X.columns:
            self.assertNotIn("list_price", column)
        forbidden = set(data.AFTER_SALE_COLUMNS + ["ml_num"])
        self.assertTrue(forbidden.isdisjoint(X.columns))

    def test_unknown_categories_do_not_change_training_levels(self):
        sales = example_sales()
        builder = PropertyFeatures("off_market").fit(sales)
        query = sales.iloc[[0]].copy()
        query["community"] = "UNSEEN"
        X = builder.transform(query)
        self.assertTrue(X["community"].isna().all())
        self.assertNotIn("UNSEEN", builder.categories["community"])

    def test_history_preserves_nonconsecutive_index_and_order(self):
        sales = example_sales()
        query = sales.iloc[[2, 0]].copy()
        output = EarlierSalesFeatures().fit(sales).transform(query)
        self.assertEqual(output.index.tolist(), [2, 0])
        self.assertAlmostEqual(output.iloc[0]["past_type_90d_log_price"], np.log(100000))
        self.assertTrue(np.isnan(output.iloc[1]["past_type_90d_log_price"]))

    def test_area_ranges_and_unfinished_basement_are_parsed(self):
        sales = example_sales()
        X = PropertyFeatures("off_market").fit(sales).transform(sales)
        self.assertEqual(X.iloc[0]["square_feet"], 1000)
        self.assertEqual(X.iloc[0]["area_range_width"], 200)
        self.assertEqual(X.iloc[0]["text_unfinished_basement"], 1)
        self.assertEqual(X.iloc[0]["text_finished_basement"], 0)

    def test_calibration_uses_training_ratios(self):
        sales = example_sales().iloc[[0]].copy()
        model = ListPriceCalibration().fit(sales)
        query = sales.copy()
        query["list_price"] = 220000.0
        self.assertAlmostEqual(model.predict(query)[0], 200000.0)

    def test_boosting_returns_positive_finite_predictions(self):
        train = pd.concat([example_sales()] * 30, ignore_index=True)
        model = PropertyBoostingModel("off_market").fit(train)
        prediction = model.predict(data.hide_answers(train.iloc[:3], "off_market"))
        self.assertEqual(prediction.shape, (3,))
        self.assertTrue(np.isfinite(prediction).all())
        self.assertTrue((prediction > 0).all())


if __name__ == "__main__":
    unittest.main()
