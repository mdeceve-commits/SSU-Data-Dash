"""Compare a fixed set of models, select on four months, confirm on two.

Run: python compare_models.py
The original six-month baseline predictions are included as a cached reference.
"""

import os

os.environ.setdefault("OMP_NUM_THREADS", "4")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MPLBACKEND", "Agg")

import gc
import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd

import data
from improved_models import make_candidate


ROOT = Path(__file__).resolve().parent
os.environ.setdefault("DATA_DIR", str(ROOT / "datasets"))
TRACKS = ["off_market", "list_aware"]


def score(rows):
    signed = 100 * (rows["predicted_price"] - rows["sold_price"]) / rows["sold_price"]
    return {
        "n": len(rows), "mdape": float(signed.abs().median()),
        "mape": float(signed.abs().mean()),
        "median_signed_error": float(signed.median()),
    }


def predict_month(model, train, homes, month, track, name, phase):
    started = perf_counter()
    model.fit(train)
    inputs = data.hide_answers(homes, track)
    predicted = np.round(model.predict(inputs))
    if predicted.shape != (len(homes),):
        raise ValueError("The model returned an unexpected prediction shape.")
    if not np.isfinite(predicted).all() or (predicted <= 0).any():
        raise ValueError("Predictions must be finite and positive.")
    output = homes[["ml_num", "house_type_name", "community", "sold_price"]].copy()
    output["track"] = track
    output["month"] = str(month)
    output["model"] = name
    output["phase"] = phase
    output["predicted_price"] = predicted
    elapsed = perf_counter() - started
    return output, elapsed


def summarize(rows, keys):
    records = []
    for values, group in rows.groupby(keys, sort=True):
        values = values if isinstance(values, tuple) else (values,)
        records.append(dict(zip(keys, values)) | score(group))
    return pd.DataFrame(records)


def main():
    started = perf_counter()
    plan = json.loads((ROOT / "experiment_plan.json").read_text())
    files = ["improved_features.py", "improved_models.py", "compare_models.py", "experiment_plan.json"]
    fingerprint = {
        name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in files
    }
    fingerprint["listings_csv_sha256"] = hashlib.sha256(
        Path(data.find_file("listings")).read_bytes()
    ).hexdigest()
    fingerprint_path = ROOT / "reports/experiment_fingerprint.json"
    if fingerprint_path.exists() and json.loads(fingerprint_path.read_text()) != fingerprint:
        raise RuntimeError("Experiment code or data changed. Use a fresh output folder.")
    fingerprint_path.write_text(json.dumps(fingerprint, indent=2))
    listings = data.load("listings")
    baseline = pd.read_csv(ROOT / "outputs/baseline_validation_predictions.csv")
    baseline["model"] = "baseline"
    baseline["phase"] = np.where(
        baseline["month"].isin(plan["development_months"]),
        "development", "confirmation",
    )
    development = [baseline[baseline["phase"] == "development"]]
    timings = []
    for month in plan["development_months"]:
        period = pd.Period(month, freq="M")
        train = listings[listings["date_sold"] < period.start_time]
        homes = listings[listings["date_sold"].dt.to_period("M") == period]
        for track in TRACKS:
            for name in plan[track + "_candidates"]:
                if name == "baseline":
                    continue
                path = ROOT / "outputs" / f"development_{month}_{track}_{name}.csv"
                if path.exists():
                    rows = pd.read_csv(path)
                    elapsed = np.nan
                else:
                    model = make_candidate(name, track)
                    rows, elapsed = predict_month(
                        model, train, homes, month, track, name, "development"
                    )
                    rows.to_csv(path, index=False)
                    del model
                    gc.collect()
                development.append(rows)
                timings.append({"phase": "development", "month": month,
                                "track": track, "model": name, "seconds": elapsed})
                print(f"DEV {month} {track} {name}: MdAPE={score(rows)['mdape']:.3f}% "
                      f"time={elapsed:.1f}s", flush=True)
    development = pd.concat(development, ignore_index=True)
    dev_metrics = summarize(development, ["track", "model"])
    dev_metrics.to_csv(ROOT / "reports/development_metrics.csv", index=False)
    selected = {}
    for track in TRACKS:
        ranking = dev_metrics[dev_metrics["track"] == track].sort_values(
            ["mdape", "mape", "model"]
        )
        selected[track] = ranking.iloc[0]["model"]
    selection = {"selected": selected,
                 "selection_months": plan["development_months"],
                 "confirmation_months": plan["confirmation_months"],
                 "selection_rule": plan["selection_rule"],
                 "locked_before_confirmation": True}
    (ROOT / "selected_models.json").write_text(json.dumps(selection, indent=2))
    print("Selection locked before confirmation: " + json.dumps(selected), flush=True)

    selected_rows = [development[
        development.apply(lambda row: row["model"] == selected[row["track"]], axis=1)
    ]]
    for month in plan["confirmation_months"]:
        period = pd.Period(month, freq="M")
        train = listings[listings["date_sold"] < period.start_time]
        homes = listings[listings["date_sold"].dt.to_period("M") == period]
        for track in TRACKS:
            name = selected[track]
            if name == "baseline":
                rows = baseline[(baseline["month"] == month) & (baseline["track"] == track)]
                elapsed = 0.0
            else:
                path = ROOT / "outputs" / f"confirmation_{month}_{track}_{name}.csv"
                if path.exists():
                    rows = pd.read_csv(path)
                    elapsed = np.nan
                else:
                    model = make_candidate(name, track)
                    rows, elapsed = predict_month(
                        model, train, homes, month, track, name, "confirmation"
                    )
                    rows.to_csv(path, index=False)
                    del model
                    gc.collect()
            selected_rows.append(rows)
            timings.append({"phase": "confirmation", "month": month,
                            "track": track, "model": name, "seconds": elapsed})
            print(f"CONFIRM {month} {track} {name}: MdAPE={score(rows)['mdape']:.3f}% "
                  f"time={elapsed:.1f}s", flush=True)
    selected_rows = pd.concat(selected_rows, ignore_index=True)
    selected_rows.to_csv(ROOT / "outputs/selected_validation_predictions.csv", index=False)
    monthly = summarize(selected_rows, ["track", "model", "phase", "month"])
    monthly.to_csv(ROOT / "reports/selected_monthly_metrics.csv", index=False)
    records = []
    for phase in ["development", "confirmation", "all_six_months"]:
        for track in TRACKS:
            for name, source in [("baseline", baseline), (selected[track], selected_rows)]:
                rows = source[source["track"] == track]
                if phase != "all_six_months":
                    rows = rows[rows["phase"] == phase]
                records.append({"period": phase, "track": track,
                                "model": name} | score(rows))
    comparison = pd.DataFrame(records)
    comparison.to_csv(ROOT / "reports/comparison_summary.csv", index=False)
    pd.DataFrame(timings).to_csv(ROOT / "reports/model_timings.csv", index=False)
    print(comparison.to_string(index=False), flush=True)
    print(f"Comparison completed in {perf_counter() - started:.1f} seconds.", flush=True)


if __name__ == "__main__":
    main()
