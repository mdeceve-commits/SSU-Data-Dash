# SSU Data Dash: improved home-price prediction

This upload copy contains the validated Python implementation, two final submission CSVs, and supporting validation evidence. The models and final predictions are identical to the full experiment package. Raw competition datasets, local Python environments, IDE settings, bytecode caches, and redundant per-candidate prediction caches are excluded.

## Upload this copy to GitHub

1. Extract `SSU_GitHub_Ready.zip` into a separate folder.
2. Open the extracted `SSU_Improvement` folder in Finder or File Explorer.
3. In the GitHub repository, choose **Add file > Upload files**.
4. Drag the **contents** of `SSU_Improvement` into the upload area. This puts `README.md`, `run.py`, and `submissions/` at the repository root.
5. Keep the existing directory structure, especially `submissions/`.
6. Commit the upload and check that both final CSV files are visible at the paths below.

The ZIP is a transfer container. Upload its extracted files so reviewers can browse and run the repository. This copy is intended for upload; keep using the original local PyCharm project for day-to-day work. Browser uploads should use the clean copy without adding datasets or a Python environment first.

```text
submissions/submission_off_market.csv
submissions/submission_list_aware.csv
```

## Reproduce the results

Use Python 3.12; the recorded run used Python 3.12.14. The exact library versions are in `requirements.txt`.

Download the three official competition CSVs from:

https://huggingface.co/datasets/Baliyang/SSU_data_dash

Place them in the local `datasets/` folder, using exactly these names:

| File | Rows | Purpose |
|---|---:|---|
| `datasets/listings.csv` | 150,000 | Historical training sales, January 2021-May 2026 |
| `datasets/test_off_market.csv` | 3,974 | Hidden off-market homes |
| `datasets/test_list_aware.csv` | 4,064 | Hidden list-aware homes |

These input files are not included in the GitHub upload copy. Existing downloads with `(1)` in the filename can be copied and renamed locally. `DATA_DIR` can override the local input directory. Keep the raw datasets on your computer; they do not need to be removed from your working PyCharm project.

Run from the folder containing `run.py`:

```bash
python -m pip install -r requirements.txt
python run.py validate
python run.py report
python run.py predict
python run.py check
```

Focused tests:

```bash
python -m unittest test_improvements.py test_pipeline.py -v
```

The production commands use frozen selections from `selected_models.json`: `rich_hgb` for off-market and `rich_ratio_hgb` for list-aware. Both use scikit-learn's `HistGradientBoostingRegressor`. `predict` refits on the full supplied historical training set; no hidden prices or parameter search are used.

## Historical validation

Both tracks use 10,069 historical validation homes from December 2025 through May 2026.

| Track | Baseline MdAPE | Selected MdAPE | Selected MAPE |
|---|---:|---:|---:|
| Off-market | 20.84% | 9.79% | 12.39% |
| List-aware | 7.26% | 4.22% | 5.30% |

December-March were development months; April-May checked the frozen selections. Confirmation-period baseline errors had previously been inspected, and the six-month result includes development months. These are historical validation scores, not hidden-test scores.

See `IMPROVEMENT_RESULTS.md` for the interpretation and limitations, `COURSE_CONNECTIONS.md` for connections to the supplied lessons, and `reports/validation_report.md` for the generated validation report.

## What was omitted

The clean copy retains all Python sources, frozen selections, experiment plan, report summaries, figures, logs, three combined validation prediction files, and both final submission CSVs. Only redundant `outputs/development_*.csv` and `outputs/confirmation_*.csv` caches were removed from the full experiment archive. Run `compare_models.py` to regenerate those caches after placing the official CSVs in `datasets/`. The required baseline reference file remains included.

The repository can reproduce the selected-model validation and final submissions without the omitted caches. No fitted model binary is required; the commands train fresh models with the recorded settings.

The separate competition PDF, YouTube video, repository visibility/sharing, and official form submission still need to be completed according to the case requirements.
