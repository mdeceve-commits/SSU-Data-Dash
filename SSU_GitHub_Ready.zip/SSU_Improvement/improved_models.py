"""Small, predefined regression candidates with the starter fit/predict API."""

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

import features
import models as starter
from improved_features import PropertyFeatures, CATEGORICAL_COLUMNS


class PropertyBoostingModel:
    def __init__(self, track, use_history=False, predict_ratio=False):
        self.track = track
        self.predict_ratio = predict_ratio
        self.features = PropertyFeatures(track, use_history=use_history)
        self.model = HistGradientBoostingRegressor(
            learning_rate=0.08, max_iter=150, max_leaf_nodes=31,
            min_samples_leaf=30, l2_regularization=1.0,
            early_stopping=False, categorical_features="from_dtype",
            random_state=0,
        )

    def fit(self, train):
        self.features.fit(train)
        target = np.log(train["sold_price"].to_numpy(float))
        if self.predict_ratio:
            target -= np.log(train["list_price"].to_numpy(float))
        self.model.fit(self.features.transform(train), target)
        return self

    def predict(self, homes):
        prediction = np.exp(self.model.predict(self.features.transform(homes)))
        if self.predict_ratio:
            prediction *= homes["list_price"].to_numpy(float)
        return prediction


class ListPriceCalibration:
    """Multiply list price by the recent median sold-to-list ratio by type."""

    def fit(self, train):
        cutoff = train["date_sold"].max() - pd.Timedelta(days=365)
        recent = train.loc[train["date_sold"] >= cutoff].copy()
        recent["ratio"] = recent["sold_price"] / recent["list_price"]
        self.global_ratio = recent["ratio"].median()
        self.ratios = recent.groupby("house_type_name")["ratio"].median()
        return self

    def predict(self, homes):
        factor = homes["house_type_name"].map(self.ratios)
        factor = factor.fillna(self.global_ratio).to_numpy(float)
        return homes["list_price"].to_numpy(float) * factor


class PropertyRandomForest:
    """A bounded-compute random-forest comparison using one-hot categories."""

    def fit(self, train):
        self.features = PropertyFeatures("off_market").fit(train)
        X = self.features.transform(train)
        numeric = [c for c in X.columns if c not in CATEGORICAL_COLUMNS]
        preprocess = ColumnTransformer([
            ("numbers", SimpleImputer(strategy="median", add_indicator=True), numeric),
            ("categories", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLUMNS),
        ])
        forest = RandomForestRegressor(
            n_estimators=100, max_depth=18, min_samples_leaf=8,
            max_features=0.7, max_samples=min(50000, len(train)),
            n_jobs=4, random_state=0,
        )
        self.model = Pipeline([("preprocess", preprocess), ("forest", forest)])
        self.model.fit(X, np.log(train["sold_price"].to_numpy(float)))
        return self

    def predict(self, homes):
        return np.exp(self.model.predict(self.features.transform(homes)))


def make_candidate(name, track):
    """Instantiate one fixed candidate; no validation-dependent parameters."""
    if name == "baseline":
        return starter.make_model(track)
    if name == "starter_hgb":
        make_features = (
            features.off_market_features if track == "off_market"
            else features.list_aware_features
        )
        return starter.FeatureModel(make_features)
    if name == "rich_hgb" and track == "off_market":
        return PropertyBoostingModel(track)
    if name == "history_hgb" and track == "off_market":
        return PropertyBoostingModel(track, use_history=True)
    if name == "random_forest" and track == "off_market":
        return PropertyRandomForest()
    if name == "ratio_calibration" and track == "list_aware":
        return ListPriceCalibration()
    if name == "rich_ratio_hgb" and track == "list_aware":
        return PropertyBoostingModel(track, predict_ratio=True)
    raise ValueError(f"Unknown candidate {name!r} for track {track!r}.")
