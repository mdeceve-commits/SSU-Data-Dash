# Competition datasets

Copy the existing competition CSV files here:

- listings.csv
- test_off_market.csv
- test_list_aware.csv

The model-comparison experiment uses listings.csv. The hidden test datasets are not used for model selection.
