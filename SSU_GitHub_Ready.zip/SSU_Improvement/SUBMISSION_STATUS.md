# Submission generation status

## Completed in this step

- Connected the official `run.py` commands to frozen validated selections: `rich_hgb` for off-market and `rich_ratio_hgb` for list-aware.
- Kept earlier uploaded submission CSVs intact and used them only for ID/format and prediction comparisons.
- Refit both selected models on the 150,000 historical training sales from January 2021 through May 2026.
- Generated new `submissions/submission_off_market.csv` (3,974 homes) and `submissions/submission_list_aware.csv` (4,064 homes).
- Checked the exact header, complete and unique test IDs, positive finite prices, and test-file row order.
- Verified that training and hidden test IDs do not overlap and no training sale is dated June 2026 or later.
- Ran both official submission commands and reproduced official validation/report commands with selected production models.
- Preserved the feature/model configuration used in the prior comparison experiment.
- Added focused tests for model routing, invalid predictions, and preserving existing files when either track fails.

## Required submission locations

```text
submissions/submission_off_market.csv
submissions/submission_list_aware.csv
```

Each file has exactly two columns: `ml_num,predicted_price`. Hidden sale prices are unavailable. Format and provenance checks do not measure hidden-test accuracy.

See `reports/final_submission_audit.json` for actual check results and comparisons with earlier uploaded CSVs. See `reports/submission_generation.json` for source/input hashes and the generation record. Official monthly validation should reproduce the earlier selected-model results: off-market MdAPE 9.79%, list-aware MdAPE 4.22% (December 2025-May 2026).

## Still required for the complete competition submission

The following are outside this code-and-CSV step and are not marked complete:

1. A report using the starter template, at most four pages, with every team member's full name, both validation MdAPEs, methods, error analysis, limitations, and working video/GitHub links.
2. A YouTube video of at most five minutes, public or unlisted rather than private.
3. A public GitHub repository or a repository shared with organisers, containing code, reproduction instructions, and both final CSVs.
4. Submission of the PDF through the official form by November 8, 2026, 11:59 pm EST, according to the uploaded case PDF.

The prepared code archive is not itself an official form submission. The generated validation report is supporting material rather than the final four-page PDF.
