"""Checks for selected-model routing and safe submission replacement."""

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

import data
import run
from improved_models import PropertyBoostingModel
from pipeline_models import checked_predictions, make_model
from test_improvements import example_sales


class SubmissionPipelineChecks(unittest.TestCase):
    def test_commands_use_the_validated_estimators(self):
        off_market = make_model("off_market")
        list_aware = make_model("list_aware")
        self.assertIsInstance(off_market, PropertyBoostingModel)
        self.assertIsInstance(list_aware, PropertyBoostingModel)
        self.assertFalse(off_market.predict_ratio)
        self.assertTrue(list_aware.predict_ratio)
        with self.assertRaises(ValueError):
            make_model("unknown")

    def test_invalid_or_misaligned_prices_are_rejected(self):
        for prices in [np.array([[1.0, 2.0]]), [1.0], [1.0, np.nan],
                       [1.0, np.inf], [1.0, -2.0], [1.0, 0.1]]:
            with self.subTest(prices=str(prices)), self.assertRaises(ValueError):
                checked_predictions(prices, 2)

    def test_second_track_failure_preserves_both_existing_files(self):
        train = example_sales()
        homes = train.iloc[:2].copy()
        homes["ml_num"] = ["hidden_a", "hidden_b"]

        def fake_load(name):
            return train if name == "listings" else data.hide_answers(homes, name)

        class FakeModel:
            def __init__(self, track):
                self.track = track
                self.features = self

            def fit(self, rows):
                return self

            def transform(self, rows):
                return rows[["bedrooms"]]

            def predict(self, rows):
                return np.array([500000.0, np.nan if self.track == "list_aware" else 600000.0])

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "submissions").mkdir()
            paths = [root / f"submissions/submission_{track}.csv" for track in run.TRACKS]
            for path in paths:
                path.write_text("existing valid submission\n")
            with patch.object(run, "ROOT", root), patch.object(run.data, "load", side_effect=fake_load), \
                    patch.object(run, "make_model", side_effect=FakeModel):
                with self.assertRaises(ValueError):
                    run.predict()
            self.assertTrue(all(path.read_text() == "existing valid submission\n" for path in paths))


if __name__ == "__main__":
    unittest.main()
