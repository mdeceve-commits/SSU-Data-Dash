"""Use the frozen experimental selections in the official command-line pipeline."""

import json
from pathlib import Path

import numpy as np

from improved_models import make_candidate


ROOT = Path(__file__).resolve().parent
TRACKS = ("off_market", "list_aware")
FROZEN_SELECTION = {
    "off_market": "rich_hgb",
    "list_aware": "rich_ratio_hgb",
}


def selected_names():
    """Read the selections without repeating model or parameter selection."""
    selection = json.loads((ROOT / "selected_models.json").read_text())
    names = selection["selected"]
    if names != FROZEN_SELECTION:
        raise ValueError("The saved selections differ from the validated frozen models.")
    return dict(names)


def make_model(track):
    """Return the same selected estimator used in historical validation."""
    if track not in TRACKS:
        raise ValueError(f"Unknown track: {track!r}.")
    return make_candidate(selected_names()[track], track)


def checked_predictions(values, n_homes):
    """Reject invalid model output before writing a submission or validation file."""
    prices = np.asarray(values, dtype=float)
    if prices.shape != (n_homes,):
        raise ValueError(f"Expected {n_homes} predictions, received shape {prices.shape}.")
    prices = np.round(prices)
    if not np.isfinite(prices).all() or (prices <= 0).any():
        raise ValueError("Every rounded predicted price must be finite and positive.")
    return prices
