# How the improvements connect to the supplied course materials

The implementation retains the course's practical structure: import the estimator, build features, fit on training data, predict unseen rows, and calculate evaluation metrics. Code, comments, and output labels are in English for later report writing.

## Feature engineering

Source: `3 特征工程 live.pdf`, pages 9 to 12, covering missing values and categorical encoding.

- The dataset has approximately 58.2% missing values in both lot dimensions. Histogram gradient boosting keeps these values missing and learns missing-value branches. The random-forest comparison uses training-fitted median imputation and missingness indicators.
- Community, municipality, house style, and property type are nominal categories. The forest uses `OneHotEncoder(handle_unknown="ignore")`; the boosting models use native categorical features with category levels learned from the training fold only.
- The starter already converts area ranges to their midpoint. The new features also retain range width, add lot area, garage information, and room counts relative to floor area.
- Predefined listing-description flags cover updates, original finishes, unfinished basements, amenities, and similar observable listing information. The code does not extract prices from descriptions.

The course's distinction between scaling and regularization is retained. These tree models do not need StandardScaler. Native missing-value and categorical support in HistGradientBoostingRegressor is checked against the installed scikit-learn interface rather than the older versions printed in the PDFs.

## Random forests and model complexity

Source: `2 随机森林 live.pdf`, pages 3, 5, and 9 to 10, covering regression estimators, forest parameters, and complexity/generalization.

The supplied random-forest code example is a classification teaching example. The competition predicts a continuous price, so the comparison uses `RandomForestRegressor` and learns log sale price. It retains familiar parameters: number of trees, maximum depth, minimum samples per leaf, feature subsampling, and a random seed. The number of sampled rows per tree is capped to keep the comparison manageable.

The custom handwritten forest and SVM teaching scripts are useful for understanding algorithms. The implemented comparisons use maintained estimator classes with an explicit feature/target separation.

## Boosting

Source: `11 XGBoost live.pdf`, pages 5 to 8 and 15 to 17, introducing sequential tree ensembles, learning rate, and regression evaluation.

The starter contains a ready-to-use HistGradientBoostingRegressor. The new candidates extend that existing estimator with richer features and fixed regularization settings. HistGradientBoostingRegressor is a gradient-boosted tree estimator from scikit-learn; it is not the xgboost package or XGBRegressor.

The richer and historical-feature boosting candidates share the same fixed hyperparameters. Their comparison helps assess the added historical features under that shared configuration. The starter-versus-rich comparison also changes regularization and iteration settings, so it is not a pure feature-only ablation.

## Regression metrics and target design

Source: `9 线性回归 live.pdf`, pages 10 to 14, covering regression evaluation and careful use of metrics.

The competition is ranked by MdAPE, with MAPE breaking ties. Candidate selection therefore uses pooled development MdAPE, rather than training accuracy or R-squared. The existing log-price target is retained for off-market candidates. For the list-aware boosting candidate, the target is the log sold-to-list ratio, and the prediction is converted back to a price using the known list price.

A simple calibration candidate learns recent median sold-to-list ratios by property type. This directly investigates the positive signed bias observed in the original list-price baseline.

## Historical features and leakage checks

The competition handout suggests comparable sales and market-trend features. The new historical features summarize log sale prices and log price per square foot over the preceding 90 and 365 days, grouped by property type, community, and their combination.

For each row, a historical sale is eligible only when its sale date is strictly before that row's listing date. This excludes its own sale, same-day sales, and later sales. Empty histories remain missing. The same rule is applied when creating training and validation features.

Nine focused unittest checks cover future-price perturbations, same-day exclusion, exact trailing-window behaviour, row/index alignment, forbidden off-market columns, unknown categories, text/area parsing, calibration, and positive finite model predictions.

## Validation discipline

All training folds follow the starter's monthly sale-date cutoffs. December 2025 through March 2026 are used to compare the predefined candidates and select one model per track. The selections are saved before the selected models are evaluated on April and May 2026.

Baseline results for April and May had already been inspected in the previous task. These two months are a reserved confirmation period for the new candidates, not a completely untouched blind test. The hidden competition test data and labels are not used for model selection.

## Official technical references

- https://scikit-learn.org/stable/modules/ensemble.html#histogram-based-gradient-boosting
- https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.HistGradientBoostingRegressor.html
- https://scikit-learn.org/stable/common_pitfalls.html#data-leakage
